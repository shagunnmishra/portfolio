# **App Name**: Shagun: Portfolio

## Core Features:

- Luxury Bio Module: A high-end introduction of Shagun's B.Tech ECE background at Dr. Ram Manohar Lohia Avadh University and her passion for the intersection of hardware and software.
- Achievements Timeline: A chronological showcase of professional milestones including SheFi’14, SheCodes, GSSoC’25, and IIT Guwahati ECell ambassadorships.
- Skills Matrix: A visual display of technical expertise ranging from programming (Python, C++, SQL) to engineering tools (MATLAB, Embedded C) and web technologies.
- Project Showcase Tool: An interactive gallery of real-world projects such as the Automatic Vehicle Accident Detector and Tic Tac Toe AI, utilizing a reasoning tool to answer specific recruiter queries about the technical architecture.
- Experience Catalog: A detailed section documenting Open Source contributions at SWoC and OSCG along with leadership highlights from the SIH internal hackathon win.
- Connect Gateway: A minimalist portal featuring direct, clickable links to LinkedIn (highlighting 10k+ followers), GitHub, and email.

## Style Guidelines:

- Luxury dark aesthetic featuring soft Periwinkle Grey (#D4D9F0) for text, a deep desaturated background (#0F1014), and muted Slate Blue (#617AB0) accents.
- Premium font pairing using 'Literata' (serif) for intellectual prestige in headlines and 'Inter' (sans-serif) for technical clarity in body text.
- Ultra-thin, minimalist line icons for social platforms to ensure a high-end, uncluttered visual experience.
- Single-column focal layout with expansive negative space to drive the luxury minimal and premium restraint philosophy.
- Silky-smooth vertical scrolling and soft cross-fade transitions between project cards and sections.