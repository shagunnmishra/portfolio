import { config } from 'dotenv';
config();

import '@/ai/flows/recruiter-project-query.ts';