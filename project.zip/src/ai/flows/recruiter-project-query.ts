'use server';
/**
 * @fileOverview This file defines a Genkit flow for recruiters to query technical details about Shagun's projects.
 *
 * - recruiterProjectQuery - A function that handles recruiter queries about projects.
 * - RecruiterProjectQueryInput - The input type for the recruiterProjectQuery function.
 * - RecruiterProjectQueryOutput - The return type for the recruiterProjectQuery function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RecruiterProjectQueryInputSchema = z.object({
  projectName: z.string().describe("The name of the project the recruiter is asking about."),
  question: z.string().describe("The recruiter's question about the project's technical details or architecture."),
});
export type RecruiterProjectQueryInput = z.infer<typeof RecruiterProjectQueryInputSchema>;

const RecruiterProjectQueryOutputSchema = z.object({
  answer: z.string().describe("A concise, AI-generated answer to the recruiter's question about the project."),
});
export type RecruiterProjectQueryOutput = z.infer<typeof RecruiterProjectQueryOutputSchema>;

export async function recruiterProjectQuery(input: RecruiterProjectQueryInput): Promise<RecruiterProjectQueryOutput> {
  return recruiterProjectQueryFlow(input);
}

const recruiterProjectQueryPrompt = ai.definePrompt({
  name: 'recruiterProjectQueryPrompt',
  input: {schema: RecruiterProjectQueryInputSchema},
  output: {schema: RecruiterProjectQueryOutputSchema},
  prompt: `You are an AI assistant specialized in providing technical insights for projects in Shagun's portfolio.
Shagun (She/Her) is a B.Tech ECE student passionate about embedded systems, programming, and signal processing.

Here is a list of Shagun's key projects:
- Automatic Vehicle Accident Detector: Embedded system that detects vehicle accidents in real-time and sends GPS alerts to emergency contacts.
- Tic Tac Toe AI: implementation using the Minimax algorithm for unbeatable logic-based decision-making.
- BlushBloom: A cycle logging and health tracking platform with mood analytics and comfort tips.
- Interactive FIR/IIR Filter Design: A MATLAB tool for visualizing and designing Finite and Infinite Impulse Response digital filters.

Your task is to answer a recruiter's question about a specific project from this list. 
Provide a concise, engineering-focused answer about the technical details or architecture of the project.
If the project name implies a common technical solution (like Minimax for Tic Tac Toe), elaborate on those specific technical concepts.
Maintain a strictly professional tone. Do not use generic marketing buzzwords.

---
Project Name: {{{projectName}}}
Question: {{{question}}}
---
Concise Technical Answer:`,
});

const recruiterProjectQueryFlow = ai.defineFlow(
  {
    name: 'recruiterProjectQueryFlow',
    inputSchema: RecruiterProjectQueryInputSchema,
    outputSchema: RecruiterProjectQueryOutputSchema,
  },
  async input => {
    const {output} = await recruiterProjectQueryPrompt(input);
    return output!;
  }
);
