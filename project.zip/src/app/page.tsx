import Hero from '@/components/portfolio/Hero';
import Timeline from '@/components/portfolio/Timeline';
import Skills from '@/components/portfolio/Skills';
import Projects from '@/components/portfolio/Projects';
import Experience from '@/components/portfolio/Experience';
import Footer from '@/components/portfolio/Footer';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Timeline />
      <Skills />
      <Projects />
      <Experience />
      <Footer />
    </main>
  );
}