import React from 'react';
import { GitBranch, Users, Lightbulb } from 'lucide-react';

const experiences = [
  {
    title: "Open Source Contributor",
    org: "Social Winter of Code (SWoC)",
    icon: GitBranch,
    description: "Engaged in collaborative software development, focusing on modularity and code efficiency within open-source projects."
  },
  {
    title: "Open Source Contributor",
    org: "Open Source Connect Global (OSCG)",
    icon: Users,
    description: "Contributed to technical documentation and performance optimization across distributed software repositories."
  },
  {
    title: "Team Leader & Winner",
    org: "SIH Internal Hackathon",
    icon: Lightbulb,
    description: "Managed technical strategy and team coordination to develop a functional prototype under strict time constraints."
  }
];

export default function Experience() {
  return (
    <section className="py-24 px-6 md:px-12 lg:px-24 bg-card/5 border-t border-border/10">
      <div className="max-w-4xl mx-auto space-y-16">
        <div className="space-y-4">
          <p className="text-primary tracking-[0.2em] text-xs font-semibold uppercase">Professional Experience</p>
          <h2 className="font-headline text-4xl md:text-5xl">Collaborative Contributions</h2>
        </div>
        
        <div className="grid grid-cols-1 gap-8">
          {experiences.map((exp, idx) => (
            <div 
              key={idx}
              className="group p-8 border border-border/20 bg-background hover:border-primary/40 transition-all duration-300"
            >
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className="p-3 bg-primary/10 text-primary border border-primary/20">
                  <exp.icon className="w-6 h-6" />
                </div>
                <div className="space-y-3">
                  <h3 className="font-headline text-2xl text-foreground group-hover:text-primary transition-colors">{exp.title}</h3>
                  <p className="text-xs uppercase tracking-widest text-primary font-semibold">{exp.org}</p>
                  <p className="text-muted-foreground font-body leading-relaxed max-w-2xl">
                    {exp.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
