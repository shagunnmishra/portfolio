import React from 'react';
import { Linkedin, Github, Mail, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="contact" className="py-24 px-6 md:px-12 lg:px-24 bg-background border-t border-border">
      <div className="max-w-4xl mx-auto flex flex-col items-center text-center space-y-16">
        <div className="space-y-4">
          <p className="text-muted-foreground tracking-[0.2em] text-xs font-semibold uppercase">Professional Outreach</p>
          <h2 className="font-headline text-4xl md:text-5xl tracking-tight">Connect With Me</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-2xl">
          <a 
            href="https://www.linkedin.com/in/shagunn06/" 
            target="_blank"
            rel="noopener noreferrer"
            className="group flex flex-col items-center p-8 border border-border hover:border-primary/40 transition-all duration-300 relative"
          >
            <Linkedin className="w-6 h-6 mb-4 text-muted-foreground group-hover:text-primary transition-colors" />
            <span className="font-headline text-lg">LinkedIn</span>
            <span className="text-[10px] text-muted-foreground tracking-widest uppercase mt-1">10,000+ Followers</span>
            <ArrowUpRight className="w-3 h-3 absolute top-4 right-4 opacity-0 group-hover:opacity-40 transition-opacity" />
          </a>
          
          <a 
            href="https://github.com/shagunnmishra" 
            target="_blank"
            rel="noopener noreferrer"
            className="group flex flex-col items-center p-8 border border-border hover:border-primary/40 transition-all duration-300 relative"
          >
            <Github className="w-6 h-6 mb-4 text-muted-foreground group-hover:text-primary transition-colors" />
            <span className="font-headline text-lg">GitHub</span>
            <span className="text-[10px] text-muted-foreground tracking-widest uppercase mt-1">Source Code</span>
            <ArrowUpRight className="w-3 h-3 absolute top-4 right-4 opacity-0 group-hover:opacity-40 transition-opacity" />
          </a>
          
          <a 
            href="mailto:shagun4kashyap@gmail.com" 
            className="group flex flex-col items-center p-8 border border-border hover:border-primary/40 transition-all duration-300 relative"
          >
            <Mail className="w-6 h-6 mb-4 text-muted-foreground group-hover:text-primary transition-colors" />
            <span className="font-headline text-lg">Email</span>
            <span className="text-[10px] text-muted-foreground tracking-widest uppercase mt-1">Direct Contact</span>
            <ArrowUpRight className="w-3 h-3 absolute top-4 right-4 opacity-0 group-hover:opacity-40 transition-opacity" />
          </a>
        </div>
        
        <div className="pt-16 border-t border-border w-full flex flex-col md:flex-row justify-between items-center gap-4 text-muted-foreground text-[10px] uppercase tracking-[0.2em]">
          <p>&copy; 2025 Shagun Mishra</p>
          <p>B.Tech Electronics & Communication Engineering</p>
        </div>
      </div>
    </footer>
  );
}
