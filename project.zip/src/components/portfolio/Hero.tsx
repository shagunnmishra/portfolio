import React from 'react';
import { Button } from "@/components/ui/button";
import { Mail, ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section className="min-h-[80vh] flex flex-col justify-center px-6 md:px-12 lg:px-24 py-20 bg-background relative overflow-hidden">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="space-y-4">
          <p className="text-primary tracking-[0.2em] text-xs font-semibold uppercase">Professional Profile</p>
          <h1 className="font-headline text-5xl md:text-7xl lg:text-8xl tracking-tight leading-tight text-foreground">
            Shagun <span className="text-muted-foreground/40 italic text-2xl md:text-4xl align-middle font-normal ml-2">(She/Her)</span>
          </h1>
        </div>
        
        <div className="space-y-8">
          <div className="h-[2px] w-24 bg-primary"></div>
          <p className="font-headline text-xl md:text-3xl leading-relaxed text-foreground max-w-3xl">
            B.Tech Electronics and Communication Engineering Student at Dr. Ram Manohar Lohia Avadh University.
          </p>
          <p className="font-body text-base md:text-lg text-muted-foreground max-w-2xl leading-loose">
            Specializing in embedded systems, digital signal processing, and software development with a focus on engineering efficiency and technical excellence.
          </p>
          
          <div className="flex flex-wrap gap-4 pt-4">
            <Button asChild className="rounded-none h-12 px-8 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300">
              <a href="#contact" className="flex items-center gap-2">
                <Mail className="w-4 h-4" /> Contact Me
              </a>
            </Button>
            <Button asChild variant="outline" className="rounded-none h-12 px-8 border-border hover:bg-accent transition-all duration-300">
              <a href="#projects" className="flex items-center gap-2">
                View Projects <ArrowRight className="w-4 h-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce opacity-40">
        <div className="w-[1px] h-12 bg-foreground"></div>
      </div>
    </section>
  );
}
