"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { recruiterProjectQuery } from "@/ai/flows/recruiter-project-query";
import { Send, Loader2, Sparkles } from "lucide-react";

interface ProjectInteractionProps {
  projectName: string;
}

export default function ProjectInteraction({ projectName }: ProjectInteractionProps) {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);
    try {
      const result = await recruiterProjectQuery({ projectName, question });
      setAnswer(result.answer);
    } catch (error) {
      console.error("AI Error:", error);
      setAnswer("I'm sorry, I couldn't retrieve that technical detail right now.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-8 pt-8 border-t border-border/20">
      <p className="text-xs font-semibold text-primary/60 tracking-wider uppercase mb-4 flex items-center gap-2">
        <Sparkles className="w-3 h-3" /> Technical Query Tool
      </p>
      
      <form onSubmit={handleQuery} className="flex gap-2">
        <Input 
          placeholder={`Ask a technical question about ${projectName}...`}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          className="bg-background/20 border-border/40 focus:ring-primary/40 focus:border-primary/40 rounded-none h-11 text-xs md:text-sm"
        />
        <Button 
          type="submit" 
          disabled={loading}
          variant="outline"
          className="rounded-none border-border/40 hover:bg-primary/10 hover:border-primary/60 transition-all h-11 px-4"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </Button>
      </form>

      {answer && (
        <div className="mt-4 p-4 bg-primary/5 border-l-2 border-primary/40 animate-in fade-in slide-in-from-top-2 duration-500">
          <p className="text-sm text-foreground/90 leading-relaxed font-body italic">
            {answer}
          </p>
        </div>
      )}
    </div>
  );
}