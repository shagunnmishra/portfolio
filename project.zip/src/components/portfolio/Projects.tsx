import React from 'react';
import ProjectInteraction from './ProjectInteraction';
import { Button } from "@/components/ui/button";
import { Github, ExternalLink } from "lucide-react";

const projects = [
  {
    name: "Automatic Vehicle Accident Detector",
    description: "Embedded system that detects accidents in real time using specialized sensors and sends GPS alerts to emergency contacts for rapid response.",
    repo: "https://github.com/shagunnmishra/Automatic_vehicle_accident_detector",
    demo: null
  },
  {
    name: "Tic Tac Toe AI",
    description: "Smart Tic Tac Toe game with unbeatable AI implementation using the Minimax algorithm. Fully interactive and browser-based experience.",
    repo: "https://github.com/shagunnmishra/tic_tac_toe_ai",
    demo: "https://shagunnmishra.github.io/tic_tac_toe_ai/"
  },
  {
    name: "BlushBloom",
    description: "A comprehensive period tracker featuring cycle logging, mood tracking, reminders, comfort tips, and visual data statistics.",
    repo: null,
    demo: "https://shagunnmishra.github.io/blushbloom"
  },
  {
    name: "Interactive FIR/IIR Filter Design",
    description: "Interactive MATLAB project designed for the visualization and analysis of Finite and Infinite Impulse Response digital filters.",
    repo: "https://github.com/shagunnmishra/interactive_fir_iir_filterdesign",
    demo: null
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 px-6 md:px-12 lg:px-24 bg-background border-t border-border/10">
      <div className="max-w-4xl mx-auto space-y-20">
        <div className="space-y-4">
          <p className="text-primary tracking-[0.2em] text-xs font-semibold uppercase">Technical Portfolio</p>
          <h2 className="font-headline text-4xl md:text-5xl">Selected Projects</h2>
        </div>
        
        <div className="space-y-24">
          {projects.map((project, idx) => (
            <div key={idx} className="group space-y-8 pb-16 border-b border-border/10 last:border-0">
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <h3 className="font-headline text-3xl md:text-4xl text-foreground">{project.name}</h3>
                  <div className="flex gap-3">
                    {project.repo && (
                      <Button asChild variant="outline" size="sm" className="rounded-none border-border/40 hover:bg-primary/5">
                        <a href={project.repo} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                          <Github className="w-4 h-4" /> Repo
                        </a>
                      </Button>
                    )}
                    {project.demo && (
                      <Button asChild variant="outline" size="sm" className="rounded-none border-border/40 hover:bg-primary/5">
                        <a href={project.demo} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                          <ExternalLink className="w-4 h-4" /> Live Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
                
                <p className="text-muted-foreground font-body text-lg leading-relaxed max-w-3xl">
                  {project.description}
                </p>
                
                <ProjectInteraction projectName={project.name} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
