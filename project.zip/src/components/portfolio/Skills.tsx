import React from 'react';

const skillGroups = [
  {
    title: "Programming",
    skills: ["Python", "C", "C++", "SQL", "DSA"]
  },
  {
    title: "Web & Design",
    skills: ["React", "JavaScript", "HTML5", "CSS3"]
  },
  {
    title: "Engineering",
    skills: ["MATLAB", "Embedded C"]
  },
  {
    title: "Interests",
    skills: ["Robotics", "Blockchain", "AI Tools", "Embedded Systems"]
  }
];

export default function Skills() {
  return (
    <section className="py-32 px-6 md:px-12 lg:px-24 bg-card/30 backdrop-blur-sm">
      <div className="max-w-4xl mx-auto space-y-20">
        <div className="space-y-4">
          <p className="text-primary tracking-[0.2em] text-xs font-semibold uppercase">Technical Expertise</p>
          <h2 className="font-headline text-4xl md:text-5xl">The Skills Matrix</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-16">
          {skillGroups.map((group, idx) => (
            <div key={idx} className="space-y-8">
              <h3 className="font-headline text-lg border-b border-primary/20 pb-2">{group.title}</h3>
              <div className="flex flex-wrap gap-4">
                {group.skills.map((skill, sIdx) => (
                  <div 
                    key={sIdx}
                    className="px-4 py-2 border border-border/40 bg-background/50 text-foreground/80 text-sm font-medium hover:border-primary/60 hover:text-primary transition-all duration-300"
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}