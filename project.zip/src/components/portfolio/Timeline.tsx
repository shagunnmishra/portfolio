import React from 'react';
import { Award, Target, ExternalLink } from 'lucide-react';

const achievements = [
  {
    role: "Campus Ambassador",
    org: "GirlScript Summer of Code (GSSoC’25)",
    year: "2025",
    description: "Promoting open-source culture and community engagement at the university level."
  },
  {
    role: "Campus Ambassador",
    org: "IIT Guwahati ECell",
    year: "2024",
    description: "Driving entrepreneurial spirit and networking initiatives."
  },
  {
    role: "SheFi’14 Scholar",
    org: "SheFi Community",
    year: "2024",
    description: "Exploring decentralized finance and blockchain technology."
  },
  {
    role: "SheCodes Scholar",
    org: "SheCodes Foundation",
    year: "2024",
    description: "Intensive training in modern web development frameworks."
  },
  {
    role: "Team Leader – Winner",
    org: "SIH Internal Hackathon (College Level)",
    year: "2024",
    description: "Led a cross-functional team to victory in a high-pressure solution-building environment."
  }
];

export default function Timeline() {
  return (
    <section className="py-32 px-6 md:px-12 lg:px-24 bg-background border-y border-border/10">
      <div className="max-w-4xl mx-auto space-y-16">
        <div className="space-y-4 text-center md:text-left">
          <p className="text-primary tracking-[0.2em] text-xs font-semibold uppercase">Achievements</p>
          <h2 className="font-headline text-4xl md:text-5xl">Professional Milestones</h2>
        </div>
        
        <div className="space-y-12">
          {achievements.map((item, idx) => (
            <div 
              key={idx} 
              className="group relative grid grid-cols-1 md:grid-cols-[100px_1fr] gap-4 md:gap-12 pb-12 border-b border-border/20 last:border-0 transition-all"
            >
              <div className="text-muted-foreground font-body text-sm pt-1">{item.year}</div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-headline text-xl md:text-2xl group-hover:text-primary transition-colors">{item.org}</h3>
                  <Award className="w-4 h-4 text-primary/40 group-hover:text-primary transition-all" />
                </div>
                <p className="text-foreground/80 font-medium text-sm md:text-base tracking-wide uppercase text-xs md:text-sm">{item.role}</p>
                <p className="text-muted-foreground font-body leading-relaxed max-w-2xl">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}